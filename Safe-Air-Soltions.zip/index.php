<?php

if (isset($_POST['submit'])) {
  $name = $_POST['name'];
  $subject = $_POST['subject'];
  $mailFrom = $_POST['name'];
  $message = $_POST['message'];

  $mailTo = "childco5@wsdstudent.net";
  $headers = "Form: ".$mailForm;
  $txt = "You have recived an e-mail from ".$name.".\n\n".$message;

  mail($mailTo, $subject, $txt, $headers);
  header("Location: index.php?mailsend");
  
  
  
  
}



